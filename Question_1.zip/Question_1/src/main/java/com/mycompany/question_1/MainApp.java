/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Nasi
 */
public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        
            
        System.out.print("Enter Customer Name: ");
        String customerName = scanner.nextLine();
        
        System.out.print("Enter Product Name: ");
        String product = scanner.nextLine();
        
        System.out.print("Enter Product Price: R ");
        double price = scanner.nextDouble();
        
        //calculation
        IProductCalculation calculations = new ProductCalulation(price);
        double vat = calculations.getVat();
        double commissions = calculations.getCommission();
        double total = calculations.getTotal();  
        String commisssion = null;
        
        // formate data logs
        String dataLog = "DATA LOG\n" +
              "******************************************************\n" +
                "Customer Name: " + customerName + "/n" +
                "PRODUCT: " + product + "\n" +
                "VAT: " + vat + "\n" +
                "COMMISSION: " + commisssion + "\n" +
                "TOTAL: " + total + "\n" +
                "******************************************************\n" +
                
        System.out.println(dataLog + "\n");
        
        try (PrintWriter writer = new PrintWriter (new FileWriter ("data.txt", true)))
            write.println(dataLog);
            System.out.println("[Success] Information saved");
        } catch (IOExecption e) {
            System.err.println("[error] Could notsave file:" + e.getmessage());
        }
        
        scanner.close();
    }
}
