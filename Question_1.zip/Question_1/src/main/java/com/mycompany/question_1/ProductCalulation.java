/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_1;

/**
 *
 * @author Nasi
 */
public class ProductCalulation implements IProductCalculation {
    private double  price;
    
    public ProductCalulation(double price) {
       this.price = price;
    }
    
    @Override
    public double getVat(){
        return price * 0.15; // 15% VAT[span_0](start_span)[span_0](end_span)
    }
    
    @Override
    public double getCommission(){
        return price * 0.05; //5% commission[span_1](start_span)[span_1](end_span)
    }
    
    @Override
    public double getTotal(){
        return price + getVat() + getCommission(); // Price + VAT + Commission
    }
}
